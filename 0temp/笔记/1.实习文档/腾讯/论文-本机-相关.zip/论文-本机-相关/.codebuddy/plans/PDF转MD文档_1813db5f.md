---
name: PDF转MD文档
overview: 将PDF"从Demo到生产：广告投放Agent的架构演进与落地实践"从"1、Demo"章节开始转换为完整的Markdown文档
todos:
  - id: extract-and-convert
    content: Use [skill:pdf] 提取PDF全文并转换为完整Markdown文档（从章节1开始，含表格/代码块，清理杂讯，排除评论区）
    status: completed
---

## 用户需求

将PDF文件《从Demo到生产：广告投放Agent的架构演进与落地实践》转换为完整的Markdown文档。

## 产品概述

一份约2万字的技术文章，记录腾讯广告投放Agent从Demo到生产落地的半年架构演进过程，包含9个章节：Demo阶段、三个阶段认知演进、推理引擎、Skill体系、提案机制、测评体系、Harness工程、工程化、弯路与建议。

## 核心功能

- 从"1、Demo跑通了，然后呢？"章节开始提取，跳过封面/目录/摘要
- 完整还原所有章节文本内容，包括标题层级结构
- 正确还原PDF中的表格为Markdown表格格式
- 正确还原代码块（带语言标识）
- 保留图片引用说明（图X-X标注）
- 清理网页导航杂讯（时间戳、页码、导航栏等）
- 不包含评论区互动内容（第29-31页）

## 技术方案

- 使用Python pdfplumber库提取PDF全文和表格数据
- 通过Python脚本对提取的原始文本进行清洗和格式化处理
- 最终输出为符合Markdown规范的.md文件

## 实现策略

1. 用pdfplumber逐页提取文本和表格
2. 编写Python脚本进行以下处理：

- 定位起始点："1、Demo跑通了，然后呢？"
- 移除每页页眉（时间戳+标题+KM平台）和页脚（页码+链接）
- 移除封面页导航元素（首页、AI问答、悦读等）
- 根据标题模式识别章节层级（如"1、"为一级标题，"2.1"为二级标题等）
- 将pdfplumber提取的表格数据转为Markdown表格
- 识别代码块（缩进或标记的代码段）并包裹为```代码块
- 保留图片引用说明文字

3. 手动审校和微调，确保格式完整准确

## 实现要点

- PDF文本中存在全角字符（如"⼴告"应为"广告"），需要做全角到半角的规范化
- 表格提取需注意合并单元格和跨行情况
- 代码块需识别缩进模式（行首空格/数字编号）
- 第28页末尾为正文结束，第29页开始为评论区，需在此截断

## 目录结构

```
/Users/yb0os1/Desktop/my-code/论文-本机-相关/
├── 从Demo到生产：广告投放Agent的架构演进与落地实践 - 腾讯广告研效 - KM平台.pdf  # [源文件] 不修改
├── 从Demo到生产：广告投放Agent的架构演进与落地实践.md  # [NEW] 转换后的Markdown文档
└── extract_pdf.py  # [NEW] PDF提取和格式化脚本（辅助工具）
```

## Agent Extensions

### Skill

- **pdf**
- Purpose: 使用pdfplumber提取PDF全文和表格数据，完成PDF到Markdown的核心转换
- Expected outcome: 从PDF中提取出完整的文本内容和表格数据，清洗后输出为格式规范的Markdown文件